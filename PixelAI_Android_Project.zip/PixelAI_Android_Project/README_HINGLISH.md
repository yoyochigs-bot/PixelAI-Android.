# Pixel AI — Native Android project

Ye Android Studio project hai. Isme native Kotlin Android shell + WebView-based UI hai, aur image generation Puter.js browser SDK se hoti hai.

## Features
- Prompt-based image generation
- Puter.js `puter.ai.txt2img()`
- Model selector aur aspect ratio selector
- Preview
- Native Android Gallery save (`Pictures/PixelAI`)
- Dark UI
- Puter authentication popup support ka basic WebView handling

## Build karne ke liye
1. ZIP extract karo.
2. Android Studio mein `PixelAI_Android_Project` folder open karo.
3. Gradle sync complete hone do. JDK 17 aur Android SDK 35 install hona chahiye.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` select karo.
5. APK `app/build/outputs/apk/debug/app-debug.apk` mein milegi.

## Android phone par
Android phone par Android Studio officially available nahi hota. Phone-only build ke liye AndroidIDE jaise third-party environment ka use karna pad sakta hai; compatibility guaranteed nahi hai. Reliable route: project ko Android Studio wale PC/laptop par build karna.

## Important Puter notes
- Puter.js is loaded from `https://js.puter.com/v2/`.
- App page uses `https://appassets.androidplatform.net` local HTTPS origin, not `file://`, because Puter auth requires a valid origin.
- First generation par Puter authentication / consent flow aa sakta hai.
- Puter uses a user-pays model: AI usage can be charged to the signed-in user depending on selected model.
- The model ID `openai/gpt-image-2.6-sunburst` is retained because it was supplied in the original snippet, but its availability must be confirmed in the live Puter model catalog. If unavailable, select `gpt-image-2.6-flare` or another available model.
- This is a starter project, not a signed production release. Test sign-in, image generation, and Gallery saving on the target Android device before distribution.

## Security
The app does not contain a developer API key. The JavaScript bridge exposes only a save-image method to the bundled local page. Do not add arbitrary remote pages to the WebView allowlist.
